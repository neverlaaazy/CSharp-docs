﻿using Microsoft.Office.Interop.Word;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// Подключаем using для word
using MsWord = Microsoft.Office.Interop.Word;


namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // автоматизация ПО MS Word (COM)

            // 1) запускаем Word - процесс
            var wordApp = new MsWord.Application();

            // 3) Добавим  новый документ (или можно загрузить)
            wordApp.Documents.Add();

            // в документ запишем информацию
            // выбираем документ по номеру
            // (нумерация ведётся с 1, Microsoft для Office - Visual Basic)
            // макросы - скрипты на Basic для Office

            var doc = wordApp.Documents[1];

            // В документе основная единица - "Paragraph" - Абзац
            // абзац - текст между двумя разрывами строк "Enter"
            doc.Paragraphs.Add();
            var pr = doc.Paragraphs[1];
            pr.Range.Text = $"Hello World!, Today {DateTime.Today.ToShortDateString()}";
            // Range - диапозон - выделить блок и выполнить действия
            doc.Paragraphs.Add();
            var pr2 = doc.Paragraphs[2];
            pr2.Range.Text = "Таблица с данными:";


            //Таблицы
            doc.Paragraphs.Add();
            var pr3 = doc.Paragraphs[3];
            doc.Tables.Add(pr3.Range, 5, 4);


            pr2 = doc.Paragraphs[2];
            pr2.Alignment = MsWord.WdParagraphAlignment.wdAlignParagraphCenter;
            pr2.Range.Font.Name = "Times New Roman";
            pr2.Range.Font.Color = MsWord.WdColor.wdColorDarkBlue;
            pr2.Range.Font.Bold = 1;

            // настраиваем таблицу

            var table = doc.Tables[1];

            // внешняя граница
            table.Borders.OutsideColor = MsWord.WdColor.wdColorLime;
            table.Borders.OutsideLineStyle = MsWord.WdLineStyle.wdLineStyleDouble;

            //внутреняя граница
            table.Borders.InsideColor = MsWord.WdColor.wdColorLime;
            table.Borders.InsideLineStyle = MsWord.WdLineStyle.wdLineStyleSingle;

            //Заносим данные в таблицу
            string[] headers = { "Продукт", "Цена", "Количество", "Стоимость" };

            
            for ( int i = 0; i < headers.Length; i++)
            {
                table.Cell(1, 1 + i).Range.Text = headers[i];
                table.Cell(1, 1 + i).Range.Font.Bold = 1;
            }
            // как будто у нас есть база данных выгружаем сведения
            int countProducts = 4;
            string[] names = { "", "", "", "" };
            int[] prices = { 100, 200, 150, 400 };
            int[] quantity = { 3, 5, 2, 1 };

            int total = 0;

            for ( int i = 0; i < countProducts; i++ )
            {
                table.Cell(2+i,1).Range.Text = names[i];
                table.Cell(2+i,2).Range.Text = prices[i].ToString("c");
                table.Cell(2+i,3).Range.Text = quantity[i].ToString();
                table.Cell(2 + i, 4).Range.Text = (prices[i] * quantity[i]).ToString("c");

                int cost = (prices[i] * quantity[i]);


                total += cost;
            }

            table.Rows.Add();
            table.Cell(6,1).Merge(table.Cell(6,3));
            table.Cell(6, 1).Range.Text = "Итого";
            table.Cell(6, 2).Range.Text = total.ToString("c");

            // 2) Показать приложение (Необязательно)
            wordApp.Visible = true;

            // Режим "Тихого" сохранения документа
            object fileName = "d://file2.docx";
            try
            {
                doc.SaveAs2(fileName, FileFormat: WdSaveFormat.wdFormatDocumentDefault);
                MessageBox.Show("Документ готов");
            }
            catch(Exception ex) { MessageBox.Show(ex.Message); }

            //Закрыть текущий документ
            doc.Close();

            // автоматическое закрытие приложения word
            wordApp.Quit();
        }
    }
}
