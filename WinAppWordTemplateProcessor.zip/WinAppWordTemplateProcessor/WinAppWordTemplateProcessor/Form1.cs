﻿using Microsoft.Office.Interop.Word;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MSWord = Microsoft.Office.Interop.Word;

namespace WinAppWordTemplateProcessor
{
    public partial class Form1 : Form
    {
        private Dictionary<string, string>Template = 
            new Dictionary<string, string> 
            {
                {"@Employee", "Каво Деда"},
                {"@StartDate", "01.04.25" },
                {"@FinishDate", "01.05.25" },
                {"@Money","90.000руб" }
            };

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var wordApp = new MSWord.Application();
            wordApp.Visible = true;

            string filename = "WordTemplates\\WordTemplate.docx";
            //нужно определить местоположение нашего процесса
            string currentPath = System.Windows.Forms.Application.ExecutablePath;
            currentPath = System.IO.Path.GetDirectoryName(currentPath);
            //абсолютный путь к шаблону
            filename = System.IO.Path.Combine(currentPath, filename);

            wordApp.Documents.Open(filename);

            //берём документ
            var doc = wordApp.Documents[1];
            //выделяем весь документ
            MSWord.Range range = doc.Content;

            foreach (var item in Template)
            {
                range.Find.Execute(
                    FindText: item.Key,
                    ReplaceWith: item.Value,
                    Replace: MSWord.WdReplace.wdReplaceAll
                );
            }

            //range.Find.Execute(
            //    FindText: "@Employee",
            //    ReplaceWith: "Никита Запоминай",
            //    Replace: MSWord.WdReplace.wdReplaceAll
            //);

            //range.Find.Execute(
            //    FindText: "@StartDate",
            //    ReplaceWith: "01.05.2026",
            //    Replace: MSWord.WdReplace.wdReplaceAll
            //);

            //range.Find.Execute(
            //    FindText: "@FinishDate",
            //    ReplaceWith: "01.06.2026",
            //    Replace: MSWord.WdReplace.wdReplaceAll
            //);

            //range.Find.Execute(
            //    FindText: "@Money",
            //    ReplaceWith: "100000руб",
            //    Replace: MSWord.WdReplace.wdReplaceAll
            //);
        }
    }
}
